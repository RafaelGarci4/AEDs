public class while4e7 {
    



    public static void main(String[] args) {
        int i =1;
     
        int n  = MyIO.readInt();

        for(int j = 0; j < n; j++){
            MyIO.println(i);
            i=i+4;
            MyIO.println(i);
            i=i+7;

        }
       
    }
}
