public class primeiros10 {
    



    public static void main(String[] args) {
        int i = 0;
        while( i< 10){
            i++;
            MyIO.println(i);
            
        }
    }
}
