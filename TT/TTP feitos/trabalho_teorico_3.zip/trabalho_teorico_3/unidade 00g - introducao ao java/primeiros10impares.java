public class primeiros10impares {
    


    public static void main(String[] args) {
        int n = MyIO.readInt();
        int i =1;
        while(i < n ){
            MyIO.println(i);
            i=i+2;
        }
    }
}
