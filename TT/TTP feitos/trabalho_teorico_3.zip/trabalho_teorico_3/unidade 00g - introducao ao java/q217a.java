public class q217a {
    

    public static void main(String[] args) {
       
       
        int array[] = new int[]{10, 5, 8, 2, 8};

        for(int i = 0; i < array.length; i++){
            MyIO.println("Valor na posicao "+i+" : "+array[i]);
        }
    }
}
