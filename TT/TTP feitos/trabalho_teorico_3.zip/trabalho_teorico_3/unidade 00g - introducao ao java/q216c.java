public class q216c {
    


    public static void main(String[] args) {
        int n1[] = new int[5];
        int n2[] = new int[6];

        for(int i =0; i < 5 ; i++){
           
        MyIO.println("entre com um numero :");
        n1[i] = MyIO.readInt();

        }

        for(int i =0; i < 5 ; i++){
            MyIO.println("entre com um numero :");
            n2[i] = MyIO.readInt();
        }

       
       
       
       
        MyIO.println("Uniao entre os numeros :");

        MyIO.println("Intercessao entre os numeros :");
        
    }
}
