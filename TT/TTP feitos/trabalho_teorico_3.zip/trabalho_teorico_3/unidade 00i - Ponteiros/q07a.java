public class q07a{

    public static void main (String[] args) {
        int[] vet = new int [5];
        //escrever(vet);
        vet = new int [5];
       // escrever(vet);
        }

        // no primeiro termo ira escrever o conteudo presente na memoria de valor 5
        // no segundo ira escrever aquilo que esta na 5 posicao
}