//Arquivo ExemploArq01Escrita.java

class ExemploArq01Escrita{

    public static void main(String[] args) {
        Arq.openWrite("exemploescrita.txt");

        Arq.println(1);
        Arq.println(5.3);
        Arq.println('X');
        Arq.println(true);
        Arq.println("Algoritmos");


        Arq.close();



    }







}